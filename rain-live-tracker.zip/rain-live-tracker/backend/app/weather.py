"""Live weather + rain-amount forecast using Open-Meteo (free, no API key)."""
import json, time, urllib.parse, urllib.request

FORECAST = "https://api.open-meteo.com/v1/forecast"
GEOCODE = "https://geocoding-api.open-meteo.com/v1/search"
_cache, TTL = {}, 600   # 10-minute cache

def _get(url, params):
    with urllib.request.urlopen(f"{url}?{urllib.parse.urlencode(params)}", timeout=10) as r:
        return json.load(r)

def fetch(lat, lon):
    key = (round(lat, 2), round(lon, 2))
    if key in _cache and time.time() - _cache[key][0] < TTL:
        return _cache[key][1]
    data = _get(FORECAST, {
        "latitude": lat, "longitude": lon, "timezone": "auto", "past_days": 1, "forecast_days": 3,
        "current": "temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m,cloud_cover,pressure_msl",
        "hourly": "precipitation,precipitation_probability",
        "daily": "precipitation_sum,precipitation_probability_max,temperature_2m_max,temperature_2m_min",
    })
    _cache[key] = (time.time(), data)
    return data

def geocode(q):
    res = _get(GEOCODE, {"name": q, "count": 5, "language": "en"}).get("results", [])
    return [{"name": r["name"], "admin": r.get("admin1", ""), "country": r.get("country", ""),
             "lat": r["latitude"], "lon": r["longitude"]} for r in res]

def intensity(mm_hr):                       # per-hour rate
    if mm_hr < 0.1:  return "No rain"
    if mm_hr < 2.5:  return "Light"
    if mm_hr < 7.6:  return "Moderate"
    if mm_hr < 35.5: return "Heavy"
    return "Very heavy"

def daily_category(mm):                     # IMD 24-h classification
    if mm < 2.5:    return "Little / no rain"
    if mm < 15.6:   return "Light"
    if mm < 64.5:   return "Moderate"
    if mm < 115.6:  return "Heavy"
    if mm < 204.5:  return "Very heavy"
    return "Extremely heavy"

def analyse(data):
    h = data["hourly"]; t = h["time"]
    p = [v or 0.0 for v in h["precipitation"]]
    prob = [v or 0 for v in h["precipitation_probability"]]
    cur = data["current"]
    key = cur["time"][:13] + ":00"
    now = t.index(key) if key in t else 24

    nxt = lambda n: round(sum(p[now + 1: now + 1 + n]), 1)       # hour T = rain in the hour before T
    totals = {f"next_{n}h": nxt(n) for n in (1, 3, 6, 12, 24, 48)}
    past24 = round(sum(p[max(0, now - 23): now + 1]), 1)

    fut = range(now + 1, min(len(p), now + 25))
    start = next((i for i in fut if p[i] >= 0.2), None)
    peak = max(fut, key=lambda i: p[i], default=None)
    raining_now = cur["precipitation"] >= 0.1

    if raining_now:
        msg = f"Ippo mazhai peiyudhu ({intensity(cur['precipitation'])}, {cur['precipitation']} mm/h)."
    elif start is not None:
        msg = f"Mazhai {t[start][11:16]} mani-ku (~{start - now} hr la) aarambikkum."
    else:
        msg = "Next 24 hours-la mazhai varra chance romba kammi."
    if peak is not None and p[peak] >= 0.2:
        msg += f" Peak: {t[peak][11:16]} mani-ku (~{p[peak]:.1f} mm/h). Next 24h total: {totals['next_24h']} mm."

    hourly = [{"time": t[i], "mm": round(p[i], 1), "prob": prob[i]}
              for i in range(now + 1, min(len(t), now + 49))]
    d = data["daily"]
    daily = [{"date": d["time"][i], "rain_mm": d["precipitation_sum"][i] or 0,
              "prob": d["precipitation_probability_max"][i] or 0,
              "tmax": d["temperature_2m_max"][i], "tmin": d["temperature_2m_min"][i],
              "category": daily_category(d["precipitation_sum"][i] or 0)} for i in range(len(d["time"]))]

    return {
        "current": {"temp_c": cur["temperature_2m"], "feels_c": cur["apparent_temperature"],
                    "humidity": cur["relative_humidity_2m"], "wind_kmh": cur["wind_speed_10m"],
                    "cloud_pct": cur["cloud_cover"], "pressure_hpa": cur["pressure_msl"],
                    "rain_mm_hr": cur["precipitation"], "intensity": intensity(cur["precipitation"]),
                    "raining_now": raining_now, "time": cur["time"]},
        "forecast": {**totals, "past_24h": past24,
                     "category_24h": daily_category(totals["next_24h"]),
                     "max_prob_24h": max((prob[i] for i in fut), default=0),
                     "peak_mm_hr": round(p[peak], 1) if peak is not None else 0,
                     "peak_time": t[peak] if peak is not None and p[peak] >= 0.2 else None,
                     "start_time": t[start] if start is not None else None,
                     "message": msg},
        "hourly": hourly, "daily": daily,
        "timezone": data.get("timezone"),
    }
