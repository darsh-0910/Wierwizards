from fastapi import FastAPI, Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from .weather import fetch, analyse, geocode

app = FastAPI(title="Rain Live Tracker API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

@app.get("/api/health")
def health():
    return {"status": "ok"}

@app.get("/api/rain")
def rain(lat: float = Query(13.0827, ge=-90, le=90), lon: float = Query(80.2707, ge=-180, le=180)):
    """Current weather + how much rain is coming (1h..48h totals, peak, start time, hourly series)."""
    try:
        out = analyse(fetch(lat, lon))
    except Exception as e:
        raise HTTPException(502, f"Weather service unavailable: {e}")
    out["location"] = {"lat": lat, "lon": lon}
    return out

@app.get("/api/geocode")
def search(q: str = Query(..., min_length=2)):
    try:
        return geocode(q)
    except Exception as e:
        raise HTTPException(502, f"Geocoding unavailable: {e}")
