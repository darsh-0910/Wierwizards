# Backend (FastAPI)
    pip install -r requirements.txt
    uvicorn app.main:app --reload --port 8001
Docs: http://localhost:8001/docs
GET /api/rain?lat=&lon=   current weather + rain forecast (needs internet)
GET /api/geocode?q=Chennai  place search
