# Rain Live Tracker
    rain-live-tracker/
    ├── backend/   FastAPI -> Open-Meteo live weather + rain-amount forecast
    └── frontend/  Leaflet map + Chart.js (static)

## Run
1. cd backend && pip install -r requirements.txt && uvicorn app.main:app --reload --port 8001
2. cd frontend && python -m http.server 5500   -> http://localhost:5500
Click on map / search a place / use GPS -> live weather + how much rain is coming (1h to 48h), start time, peak, chart.
Rain radar overlay: RainViewer (button). Needs internet.
