const API = "http://localhost:8001/api";
const $ = id => document.getElementById(id);
const DEFAULT = {lat: 13.0827, lon: 80.2707};   // Chennai
let map, marker, chart, radar, pos = DEFAULT, timer = null;

map = L.map("map").setView([DEFAULT.lat, DEFAULT.lon], 10);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {attribution: "© OpenStreetMap"}).addTo(map);
map.on("click", e => setLocation(e.latlng.lat, e.latlng.lng));

function setLocation(lat, lon, zoom) {
  pos = {lat, lon};
  marker && map.removeLayer(marker);
  marker = L.marker([lat, lon]).addTo(map);
  if (zoom) map.setView([lat, lon], zoom);
  load();
}

async function load() {
  $("status").textContent = "fetching live weather…";
  try {
    const r = await fetch(`${API}/rain?lat=${pos.lat}&lon=${pos.lon}`);
    if (!r.ok) throw new Error((await r.json()).detail);
    const d = await r.json(); show(d);
    $("status").textContent = "updated " + new Date().toLocaleTimeString();
  } catch (e) { $("status").textContent = "⚠ " + e.message; }
}

const kpi = (k, v, w) => `<div class="kpi ${w ? "wide" : ""}"><span>${k}</span><b>${v}</b></div>`;

function bannerClass(mm) {              // by next-24h total (IMD-style)
  return mm < 2.5 ? "none" : mm < 15.6 ? "light" : mm < 64.5 ? "moderate" : mm < 115.6 ? "heavy" : "severe";
}

function show(d) {
  const c = d.current, f = d.forecast;
  $("banner").className = bannerClass(f.next_24h);
  $("banner").textContent = `${f.message}  [24h: ${f.category_24h}]`;
  $("now").innerHTML = kpi("Temperature", `${c.temp_c}°C (feels ${c.feels_c}°)`) + kpi("Humidity", c.humidity + "%") +
    kpi("Rain now", `${c.rain_mm_hr} mm/h · ${c.intensity}`) + kpi("Wind", c.wind_kmh + " km/h") +
    kpi("Cloud cover", c.cloud_pct + "%") + kpi("Pressure", c.pressure_hpa + " hPa");
  $("coming").innerHTML = kpi("Next 1 h", f.next_1h + " mm") + kpi("Next 3 h", f.next_3h + " mm") +
    kpi("Next 6 h", f.next_6h + " mm") + kpi("Next 12 h", f.next_12h + " mm") +
    kpi("Next 24 h", f.next_24h + " mm") + kpi("Next 48 h", f.next_48h + " mm") +
    kpi("Rain chance (max)", f.max_prob_24h + "%") + kpi("Past 24 h", f.past_24h + " mm") +
    kpi("Peak intensity", f.peak_time ? `${f.peak_mm_hr} mm/h at ${f.peak_time.slice(11, 16)}` : "—", true);
  $("days").innerHTML = d.daily.map(x =>
    `<div class="day"><span>${x.date.slice(5)}</span><span>${x.rain_mm} mm · ${x.prob}%</span><span>${x.category}</span></div>`).join("");

  const labels = d.hourly.map(h => h.time.slice(5, 16).replace("T", " "));
  chart && chart.destroy();
  chart = new Chart($("chart"), {data: {labels, datasets: [
    {type: "bar", label: "Rain (mm/h)", data: d.hourly.map(h => h.mm), backgroundColor: "#64a8ff", yAxisID: "y"},
    {type: "line", label: "Chance (%)", data: d.hourly.map(h => h.prob), borderColor: "#ef7d00", pointRadius: 0, yAxisID: "y1"}]},
    options: {scales: {y: {title: {display: true, text: "mm/h"}, beginAtZero: true},
      y1: {position: "right", min: 0, max: 100, grid: {drawOnChartArea: false}, title: {display: true, text: "%"}},
      x: {ticks: {maxTicksLimit: 12}}}}});
}

// ---- search / GPS / auto refresh / radar ----
$("go").onclick = async () => {
  const q = $("q").value.trim(); if (q.length < 2) return;
  const r = await (await fetch(`${API}/geocode?q=${encodeURIComponent(q)}`)).json();
  $("results").innerHTML = r.map((p, i) => `<div data-i="${i}">${p.name}, ${p.admin} ${p.country}</div>`).join("") || "<div>No match</div>";
  $("results").querySelectorAll("div[data-i]").forEach(el => el.onclick = () => {
    const p = r[el.dataset.i]; $("results").innerHTML = ""; setLocation(p.lat, p.lon, 11); });
};
$("q").onkeydown = e => e.key === "Enter" && $("go").click();
$("gps").onclick = () => navigator.geolocation
  ? navigator.geolocation.getCurrentPosition(p => setLocation(p.coords.latitude, p.coords.longitude, 11),
      () => $("status").textContent = "⚠ location permission blocked")
  : ($("status").textContent = "⚠ GPS not supported");
$("auto").onchange = () => { clearInterval(timer); if ($("auto").checked) timer = setInterval(load, 600000); };
$("radar").onclick = async () => {
  if (radar) { map.removeLayer(radar); radar = null; return; }
  try {
    const j = await (await fetch("https://api.rainviewer.com/public/weather-maps.json")).json();
    const f = j.radar.past[j.radar.past.length - 1];
    radar = L.tileLayer(`${j.host}${f.path}/256/{z}/{x}/{y}/2/1_1.png`, {opacity: .6, attribution: "RainViewer"}).addTo(map);
  } catch { $("status").textContent = "⚠ radar layer unavailable"; }
};

$("auto").onchange();
setLocation(DEFAULT.lat, DEFAULT.lon);
